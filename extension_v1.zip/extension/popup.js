document.addEventListener('DOMContentLoaded', function() {
    // 1. On récupère l'onglet actif
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        let activeTab = tabs[0];
        let journalName = activeTab.title; // On suppose que le titre de la page est le nom

        // 2. On interroge VOTRE API locale
        fetch(`http://127.0.0.1:8000/predict?name=${encodeURIComponent(journalName)}`)
        .then(response => response.json())
        .then(data => {
            let div = document.getElementById('result');
            
            // 3. Affichage du résultat
            if (data.is_predatory) {
                div.innerHTML = `
                    <h2 style="color:red">⚠️ DANGER DÉTECTÉ</h2>
                    <p>Risque : <b>${data.risk_score}%</b></p>
                    <p>Éditeur : ${data.details.Publisher}</p>
                `;
            } else {
                div.innerHTML = `
                    <h2 style="color:green">✅ SEMBLE FIABLE</h2>
                    <p>Risque : <b>${data.risk_score}%</b></p>
                    <p>Citations : ${data.details.oa_cited}</p>
                `;
            }
        })
        .catch(error => {
            document.getElementById('result').innerText = "Erreur : L'API ne répond pas. Vérifiez que uvicorn tourne.";
        });
    });
});